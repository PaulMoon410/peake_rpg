window.roomDetails = {};

let index = 0;
const townDescriptions = [
  "Town Gate: Worn wooden gates welcome travelers with faded signs.",
  "Cobblestone Path: Merchants walk by pulling carts of odd wares.",
  "Abandoned House: The door creaks open with the wind.",
  "Old Well: A bucket lies beside it, dry and cracked.",
  "Town Garden: Overgrown herbs mix with rare flowers.",
  "Central Plaza: The heart of the town, always busy.",
  "Courier's Post: Letters and news pile on wooden desks.",
  "Residential Alley: Faint sounds of laughter and clinking dishes.",
  "Town Archives: Scrolls line dusty wooden shelves.",
  "Back Gate: A guard leans lazily against the post.",

  "Tavern Street: Smells of ale and stew drift through the air.",
  "Tanner's Workshop: Leather scraps cover the floor.",
  "Empty Stable: The stalls are clean but quiet.",
  "Public Fountain: Cool water trickles peacefully.",
  "Children's Park: A swing creaks with every gust.",
  "General Store: You see the entry to a busy general shop.",
  "Blacksmith's Yard: Sparks rise from the anvil.",
  "Magic Shop Front: Runes flicker on the doorframe.",
  "Loom House: Fabric bolts tower near the entrance.",
  "East Watchtower: The view is hazy from dust. ",

  "Bakery: The smell of fresh bread tempts you.",
  "Cobbler's Stand: Shoes of all sizes on display.",
  "Stray Cat Alley: A dozen eyes watch from shadows.",
  "Herbalist’s Shed: Shelves overflow with dried roots.",
  "Wood Carver's Hut: Figurines line the windows.",
  "Statue Circle: Stone heroes long forgotten.",
  "Armory Display: Shiny gear waits behind glass.",
  "Enchanter's Tent: Smoke swirls under the canopy.",
  "Glassblower’s Kiln: Heat radiates from glowing coals.",
  "East Outpost: Notes pinned on a board flap in wind.",

  "Fence Row: A line of crooked posts stretches ahead.",
  "Stonecutter's Lot: Dusty blocks stacked neatly.",
  "Messenger Tunnel: Dimly lit and damp.",
  "Lantern Path: Oil lamps hang every few feet.",
  "Horse Hitch: Empty reins sway gently.",
  "Center Fountain: Children toss coins for luck.",
  "Weapon Rack: A soldier eyes you cautiously.",
  "Alchemy Entrance: A trail of powder marks the way.",
  "Weaver's Bench: The clack of looms echoes.",
  "Market Exit: The crowd thins to silence.",

  "Quiet Grove: A bench sits beneath an old tree.",
  "Bell Tower: The bronze bell is cracked.",
  "Cobbled Shortcut: Locals hurry through here.",
  "Pigeon Coop: Feathers flutter past your feet.",
  "Scroll Vendor: Bits of ink-stained parchment fly.",
  "Supply Stall: A vendor calls out deals.",
  "Forge Front: Heat shimmers in the air.",
  "Wand Seller: Glitter dances in her hair.",
  "Blank Shopfront: For lease — maybe one day.",
  "Eastern Corner: A sleepy cat blocks the road.",

  "Brick Alley: Narrow enough to squeeze through.",
  "Well Street: Moisture clings to the air.",
  "Chalk Wall: Messages from past visitors remain.",
  "Curtain Doorway: Music leaks from within.",
  "Gilded Fence: Someone polished it recently.",
  "Main Square Entry: Footsteps echo across stone.",
  "Forge Yard: Spare parts piled high.",
  "Potion Kiosk: Bottles clink as you pass.",
  "Tailor’s Display: Dresses billow in the wind.",
  "Wooden Signpost: Points in every direction.",

  "Barber’s Pole: The red spiral barely spins.",
  "Mud Patch: Someone slipped recently.",
  "Stair Nook: A child draws in chalk.",
  "Pipe Stack: Warmth seeps from underneath.",
  "Firepit Ring: Smoke rises faintly.",
  "Center Circle: Musicians gather here by night.",
  "Blade Shop: Blades gleam on velvet.",
  "Witch’s Arch: Charms dangle from strings.",
  "Market Stall: Fruit left out to ripen.",
  "North Path: Heads toward distant hills.",

  "Mason's Wall: Carvings decorate the stone.",
  "Watering Trough: Livestock left it full.",
  "Dusty Shed: Locked tight.",
  "Backyard Gate: Slightly ajar.",
  "Windmill Base: Silent and still.",
  "Gazebo Heart: Covered in petals.",
  "Shield Rack: Dust settled long ago.",
  "Crystal Cart: Faint hum inside the crate.",
  "Loom Tent: Quiet as the grave.",
  "Northeast Edge: The wall crumbles here.",

  "Old Cart: Splinters and a broken wheel.",
  "Militia Bench: Empty armor rests.",
  "Tavern Rear: Barrels smell of ale.",
  "Sleeping Dog: Don’t disturb it.",
  "Post Board: Flyers everywhere.",
  "Central Plaza: A local festival banner flaps.",
  "Guardhouse: Empty today.",
  "Mystic Booth: Cards laid out for fortune.",
  "Side Door: Locked for the night.",
  "Cliff View: The town stretches below.",

  "Dust Hill: Winds carry whispers.",
  "Fence Break: You could sneak out here.",
  "Back Field: Mostly trampled grass.",
  "Chicken Coop: They eye you.",
  "Laundry Line: Clothes flap in rhythm.",
  "Old Fountain: Dry for years.",
  "Barracks Entry: Footsteps echo ahead.",
  "Crystal Stand: Glows with enchantment.",
  "Cloak Booth: Mysterious figures shop.",
  "Town Border: A gate beyond leads outward."
];

for (let y = 0; y < 10; y++) {
  for (let x = 0; x < 10; x++) {
    const key = `${x},${y}`;
    window.roomDetails[key] = {
      name: `Town Tile (${x},${y})`,
      description: townDescriptions[index++]
    };
  }
}

// Add interior shops as enterable rooms off 5,5
window.roomDetails["shop_general_5_5"] = {
  name: "General Store",
  description: "A creaky wooden storefront filled with provisions, rope, and tin pans. A small bell jingles as you step inside.",
  objects: ["Rope", "Flint", "Ration Box"],
  npcs: ["Old Merchant"],
  exits: { out: "mainMap:5,5" }
};

window.roomDetails["shop_weapons_5_5"] = {
  name: "Weapons Store",
  description: "Weapons of all kinds line the racks — some rusted, some gleaming. A forge glows faintly in the corner.",
  objects: ["Rusty Sword", "Crossbow", "Throwing Knives"],
  npcs: ["Burly Blacksmith"],
  exits: { out: "mainMap:5,5" }
};

window.roomDetails["shop_magic_5_5"] = {
  name: "Magic Shop",
  description: "Glowing runes pulse in the air. Potions bubble behind thick glass counters, and the air smells of ozone and sage.",
  objects: ["Mana Crystal", "Healing Elixir", "Scroll of Wind"],
  npcs: ["Arcane Trader"],
  exits: { out: "mainMap:5,5" }
};
